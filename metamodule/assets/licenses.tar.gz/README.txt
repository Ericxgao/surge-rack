Surge XT MetaModule upstream notices

index.json maps upstream source paths to the verbatim license files or
leading source notices in texts/. Identical byte sequences are stored once.
repository/ paths refer to the surge-rack checkout; sdk/ paths refer to
the SDK used for this build. SDK notices include its upstream notice bundle.
Source preambles cover dependency trees, not only linked symbols. This
collection is not a corresponding-source archive or a completed release audit.
